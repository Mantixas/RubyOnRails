# frozen_string_literal: true

class MainController < ApplicationController
  layout 'application'
  def home
    @page_title = 'Main Page'
    @time_now = Time.now
  end
end
