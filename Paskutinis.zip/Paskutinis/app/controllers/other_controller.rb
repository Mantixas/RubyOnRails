# frozen_string_literal: true

class OtherController < ApplicationController
  before_action :url_selector, only: [:Random_Image_Page]

  def Random_Image_Page
    @random_img = url_selector
  end

  def Gallery
    @images = ['images1.png', 'images2.png', 'images3.jpg']
    @random_no = rand(3)
    @random_image = @images[@random_no]
    @url = ['https://github.com/Mantixas/RubyOnRails/tree/master/Ruby%201',
            'https://github.com/Mantixas/RubyOnRails/tree/master/Ruby%202',
            'https://github.com/Mantixas/RubyOnRails/tree/master/Ruby%203/Ruby%203']
    @random_url = @url[@random_no]
    @project_no = @random_no + 1
    end

  def mark
    @page_title = 'Will you pass?'
    @mark = rand(0..10)
  end

  private

  def url_selector
    temp = ['images1.png', 'images2.png', 'images3.jpg']
    temp[rand(3)]
 end

  def galerija; end
end
