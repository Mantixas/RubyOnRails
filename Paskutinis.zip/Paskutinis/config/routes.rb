Rails.application.routes.draw do
  resources :posts
  root to: 'pages#home'
  devise_for :users
  get 'Gallery', to: 'other#Gallery'
  get 'mark', to: 'other#mark'
  get 'RateUs', to: 'other#Random_Image_Page'
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
